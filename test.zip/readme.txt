[ Dave ]
Style.css (word elke opdracht geupdate)
Modules (word elke opdracht geupdate)

Home/Index		- De eerste pagina's
Doorgroei		- De eerste pagina's
Engels			- Meer info over modules
Burgerschap 		- Meer info over modules
UI/UX			- Werken met een plan
User stories		- Werken met een plan
GIT			- Lekker niet flexen
Prototyping		- Lekker niet flexen
Rekenen			- Vriendelijk mobieltje
BPV			- Vriendelijk mobieltje

[ Timo ]
Style-timo.css (word elke opdracht geupdate) (Header en footer van Dave)

Beroep (alleen html)	- De eerste pagina's
Opleiding (alleen html)	- De eerste pagina's
Nederlands		- Meer info over modules
Begeleiding		- Meer info over modules
Scrum			- Werken met een plan
Programmeren		- Werken met een plan
SQL			- Lekker niet flexen
ontwerp			- Lekker niet flexen
Wordpress		- Vriendelijk mobieltje
Loopbaan		- Vriendelijk mobieltje